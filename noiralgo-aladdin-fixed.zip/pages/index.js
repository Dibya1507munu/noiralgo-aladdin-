// pages/index.js
export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "25%" }}>
      <h1>🚀 NOIRALGO DEPLOYED SUCCESSFULLY!</h1>
      <p>You're now live on Vercel.</p>
    </div>
  );
}
